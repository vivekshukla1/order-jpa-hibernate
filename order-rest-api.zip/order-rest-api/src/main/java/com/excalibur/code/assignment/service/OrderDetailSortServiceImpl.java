package com.excalibur.code.assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.excalibur.code.assignment.model.OrderDate;
import com.excalibur.code.assignment.model.OrderDetail;
import com.excalibur.code.assignment.repository.OrderDateRepository;
import com.excalibur.code.assignment.repository.OrderDetailRepository;

@Service
public class OrderDetailSortServiceImpl implements OrderDetailSortService  {
	
	@Autowired
	private OrderDetailRepository repository;

	@Override
	public List<OrderDetail> findAllOrderDetailByAmountDesc() {
		return repository.findAllOrderDetailByAmountDesc();
	}

}
