package com.excalibur.code.assignment.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.data.annotation.CreatedDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "order_combined")
public class OrderCombined {
	
	@Id
    @GeneratedValue(generator = "orderdetail_generator")
    @SequenceGenerator(
            name = "orderdetail_generator",
            sequenceName = "orderdetail_sequence",
            initialValue = 1
    )
    private Long orderId;

   // @Column(columnDefinition = "order_amount")
    private BigDecimal order_amount;
    
    @NotBlank
    @Size(min = 3, max = 100)
    private String order_description;

    @Temporal(TemporalType.DATE)
    @Column(name = "order_date", nullable = false, updatable = false)
    @CreatedDate
    private Date orderDate;
 
	public BigDecimal getOrder_amount() {
		return order_amount;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public void setOrder_amount(BigDecimal order_amount) {
		this.order_amount = order_amount;
	}	

	public String getOrder_description() {
		return order_description;
	}

	public void setOrder_description(String order_description) {
		this.order_description = order_description;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	
}
