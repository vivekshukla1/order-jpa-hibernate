package com.excalibur.code.assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.excalibur.code.assignment.model.OrderDetail;

import java.util.List;

@Repository
public interface OrderDetailRepository extends JpaRepository<OrderDetail, Long> {
    List<OrderDetail> findByOrderId(Long orderId);
    
    @Query("FROM OrderDetail ORDER BY order_amount DESC")
    List<OrderDetail> findAllOrderDetailByAmountDesc();
}
