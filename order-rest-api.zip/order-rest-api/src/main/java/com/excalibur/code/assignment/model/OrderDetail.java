package com.excalibur.code.assignment.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name = "order_detail")

public class OrderDetail{
    @Id
    @GeneratedValue(generator = "orderdetail_generator")
    @SequenceGenerator(
            name = "orderdetail_generator",
            sequenceName = "orderdetail_sequence",
            initialValue = 1
    )
    private Long orderId;

   // @Column(columnDefinition = "order_amount")
    private BigDecimal order_amount;
    
    @NotBlank
    @Size(min = 3, max = 100)
    private String order_description;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "orderdate_orderid", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private OrderDate orderdate;
    
//    @ManyToMany(targetEntity = OrderDate.class, cascade = {CascadeType.PERSIST, CascadeType.DETACH,CascadeType.MERGE,CascadeType.REFRESH} )
//    private List<OrderDate> details;
    
//    @ManyToMany(targetEntity = OrderDate.class, mappedBy = "details", cascade = CascadeType.MERGE)    
//     private List<OrderDate> orderdetails;
   

	public BigDecimal getOrder_amount() {
		return order_amount;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public void setOrder_amount(BigDecimal order_amount) {
		this.order_amount = order_amount;
	}	

	public String getOrder_description() {
		return order_description;
	}

	public void setOrder_description(String order_description) {
		this.order_description = order_description;
	}

	public OrderDate getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(OrderDate orderdate) {
		this.orderdate = orderdate;
	}


    
}
