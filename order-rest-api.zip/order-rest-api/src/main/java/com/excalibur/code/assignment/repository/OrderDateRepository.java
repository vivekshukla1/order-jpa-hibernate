package com.excalibur.code.assignment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.excalibur.code.assignment.model.OrderDate;


@Repository
public interface OrderDateRepository extends JpaRepository<OrderDate, Long> {
	
	@Query("FROM OrderDate ORDER BY order_date ASC")
    List<OrderDate> findAllOrderByDateAsc();
}
