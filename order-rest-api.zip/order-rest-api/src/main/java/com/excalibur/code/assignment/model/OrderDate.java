package com.excalibur.code.assignment.model;

import java.util.Date;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import org.springframework.data.annotation.CreatedDate;

@Entity
@Table(name = "order_date")
	public class OrderDate {
    @Id
    @GeneratedValue(generator = "orderdate_generator",strategy = GenerationType.IDENTITY)
    @SequenceGenerator(
            name = "orderdate_generator",
            sequenceName = "orderdate_sequence",
            initialValue = 1
    )
    private Long orderid;
    
    @Temporal(TemporalType.DATE)
    @Column(name = "order_date", nullable = false, updatable = false)
    @CreatedDate
    private Date orderDate;
    
//    @ManyToMany(targetEntity = OrderDetail.class, mappedBy = "details", cascade = CascadeType.ALL)    
//     private List<OrderDetail> orderdetails;
    
//    @ManyToMany(targetEntity = OrderDetail.class, cascade = {CascadeType.PERSIST, CascadeType.DETACH,CascadeType.MERGE,CascadeType.REFRESH} )
//    private List<OrderDetail> details;


    public Long getId() {
        return orderid;
    }

    public void setId(Long id) {
        this.orderid = id;
    }

	public Long getOrderid() {
		return orderid;
	}

	public void setOrderid(Long orderid) {
		this.orderid = orderid;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
    
 
}
