package com.excalibur.code.assignment.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.excalibur.code.assignment.model.OrderDate;
import com.excalibur.code.assignment.repository.OrderDateRepository;

@Service
public class OrderDateSortServiceImpl implements OrderDateSortService {

	@Autowired
	private OrderDateRepository repository;

	@Override
	public List<OrderDate> findAllOrderByDateAsc() {
		return repository.findAllOrderByDateAsc();
	}

}
