package com.excalibur.code.assignment.controller;

import com.excalibur.code.assignment.exception.ResourceNotFoundException;
import com.excalibur.code.assignment.model.OrderCombined;
import com.excalibur.code.assignment.model.OrderDate;
import com.excalibur.code.assignment.model.OrderDetail;
import com.excalibur.code.assignment.repository.OrderDetailRepository;
import com.excalibur.code.assignment.service.OrderCombineInsertService;
import com.excalibur.code.assignment.service.OrderDateSortService;
import com.excalibur.code.assignment.service.OrderDetailSortService;
import com.excalibur.code.assignment.repository.OrderCombinedRepository;
import com.excalibur.code.assignment.repository.OrderDateRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

import java.util.ArrayList;
import java.util.List;

@RestController
public class OrderCombinedController {

	@Autowired
	private OrderDateRepository repository1;

	@Autowired
	private OrderDetailRepository repository2;

	@Autowired
	private OrderCombinedRepository ordercombinedRepository;

	@Autowired
	private OrderCombineInsertService orderCombineInsertService;

	@RequestMapping(produces = "application/json", value = "/filters", method = RequestMethod.GET)

	public @ResponseBody Page<OrderCombined> listItemsSortQuery(@PageableDefault(size = 20, page = 0) Pageable pageable,
			PagedResourcesAssembler<OrderCombined> assembler,
//         @RequestParam("filter")String filter, @RequestParam("value")String value){
			@RequestParam("value") String value) {
		// return ordercombinedRepository.findByFilter(pageable, filter, value);
		return ordercombinedRepository.findByFilter(pageable, value);

		// public @ResponseBody List<OrderCombined>
		// listItemsSortQuery(@RequestParam("filter")String filter,
		// @RequestParam("value")String value) {
//    	 public @ResponseBody List<OrderCombined> listItemsSortQuery( @RequestParam("value")String value) {
//         return ordercombinedRepository.findByFilter(value);

	}

	@PostMapping(value = "/combine/stream")
	public void insertAllOrderCombined() {
		List<OrderDate> list1 = repository1.findAllOrderByDateAsc();
		List<OrderDetail> list2 = repository2.findAllOrderDetailByAmountDesc();
		orderCombineInsertService.merge(list1, list2);
	}

}
