package com.excalibur.code.assignment.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.service.ServiceRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import com.excalibur.code.assignment.model.OrderCombined;
import com.excalibur.code.assignment.model.OrderDate;
import com.excalibur.code.assignment.model.OrderDetail;
import com.excalibur.code.assignment.repository.OrderCombinedRepository;
import com.excalibur.code.assignment.repository.OrderDetailRepository;

@Service
public class OrderCombineInsertService {

//	@Autowired
//	private SessionFactory sessionFactory;

	@Autowired
	private OrderCombinedRepository repository3;

	public void insertAllOrderCombined() {
		// private static SessionFactory sessionFactory;
		// private static ServiceRegistry serviceRegistry;

		// Session session = this.sessionFactory.getCurrentSession();
		Session session = null;
		try {
			// session = HibernateUtil.getSessionFactory().openSession();
			// session = sessionFactory.openSession();
			// Session session = this.sessionFactory.getCurrentSession();
			Transaction t = session.beginTransaction();
			org.hibernate.query.Query query = session
					.createQuery("insert into order_combined (order_id,order_date,order_amount,order_description)\r\n"
							+ "select order_id,odt.order_date,order_amount,order_description from order_date odt, order_detail odl \r\n"
							+ "where odt.orderid=odl.orderdate_orderid");
			int update = query.executeUpdate();
			if (update == 0 || update == 1) {
				System.out.println(update + " row affected");
			} else
				System.out.println(update + " rows affected");

			System.out.println("Inserted Records Successfully");
			System.out.println("Successfully updated");
			t.commit();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			session.close();
		}
	}

	// Generic function to join two lists using stream and lambda expression
	public final <T> List<? extends Object> merge(List<OrderDate> list1, List<OrderDetail> list2) {

		// Testing to fetch OrderCombinedRepository into a new list
		List<OrderCombined> list3 = repository3.findAllOrderCombinedDetailByOrderId();

		// Deleting records if already exists in OrderCombinedRepository
		if (list3.size() > 0) {
			repository3.deleteAll();
		}

		Stream.of(list1, list2).flatMap(x -> x.stream()).collect(Collectors.toList()).forEach(System.out::println);

		list3.addAll((Collection<? extends OrderCombined>) Stream.of(list1, list2).flatMap(x -> x.stream())
				.collect(Collectors.toList()));

		System.out.println(list3.size());
		
		
		return Stream.of(list1, list2).flatMap(x -> x.stream()).collect(Collectors.toList());

	}

}
