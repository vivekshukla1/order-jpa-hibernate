package com.excalibur.code.assignment.service;

import java.util.List;
import com.excalibur.code.assignment.model.OrderDetail;

public interface OrderDetailSortService {

    List<OrderDetail> findAllOrderDetailByAmountDesc();
   
}