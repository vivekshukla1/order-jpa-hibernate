package com.excalibur.code.assignment.controller;

import com.excalibur.code.assignment.exception.ResourceNotFoundException;
import com.excalibur.code.assignment.model.OrderDate;
import com.excalibur.code.assignment.repository.OrderDateRepository;
import com.excalibur.code.assignment.service.OrderDateSortService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

@RestController
public class OrderDateController {

    @Autowired
    private OrderDateRepository orderdateRepository;
    
    @Autowired
    private OrderDateSortService orderDateSortService;

    @GetMapping("/dates")
    public Page<OrderDate> getOrderDates(Pageable pageable) {
        return orderdateRepository.findAll(pageable);
    }


    @PostMapping("/dates")
    public OrderDate createOrder(@Valid @RequestBody OrderDate orderdate) {
    	 Date date = new Date();
    	 orderdate.setOrderDate(date);
        return orderdateRepository.save(orderdate);
    }  

    @GetMapping(value = "/dates/sort")
    public List<OrderDate> getAllOrderByDateAsc() {

        return orderDateSortService.findAllOrderByDateAsc();
    }


}
