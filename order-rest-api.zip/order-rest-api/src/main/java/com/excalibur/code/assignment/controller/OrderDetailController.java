package com.excalibur.code.assignment.controller;

import com.excalibur.code.assignment.exception.ResourceNotFoundException;
import com.excalibur.code.assignment.model.OrderDate;
import com.excalibur.code.assignment.model.OrderDetail;
import com.excalibur.code.assignment.repository.OrderDetailRepository;
import com.excalibur.code.assignment.service.OrderCombineInsertService;
import com.excalibur.code.assignment.service.OrderDateSortService;
import com.excalibur.code.assignment.service.OrderDetailSortService;
import com.excalibur.code.assignment.repository.OrderDateRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.List;

@RestController
public class OrderDetailController {

    @Autowired
    private OrderDetailRepository orderdetailRepository;

    @Autowired
    private OrderDateRepository orderdateRepository;
    
    @Autowired
    private OrderDetailSortService orderDetailSortService;    
    
    @Autowired
    private OrderCombineInsertService orderCombineInsertService;  
    

    @GetMapping("/orders/{orderId}/details")
    public List<OrderDetail> getOrderDetailByOrderId(@PathVariable Long orderId) {
        return orderdetailRepository.findByOrderId(orderId);
    }

    @PostMapping("/orders/{orderId}/details")
    public OrderDetail addOrderDetail(@PathVariable Long orderId,
                           @Valid @RequestBody OrderDetail orderdetail) {    	    
    	        return orderdateRepository.findById(orderId)
                .map(orderdate -> {
                    orderdetail.setOrderdate(orderdate);
                    return orderdetailRepository.save(orderdetail);
                }).orElseThrow(() -> new ResourceNotFoundException("Orderdate not found with orderid " + orderId));
    }
    
    @PostMapping(value = "/insert")
    public void insertAllOrderCombined() {

       orderCombineInsertService.insertAllOrderCombined();
    }
    
    @GetMapping(value = "/details/sort")
    public List<OrderDetail> getAllOrderDetailByAmountDesc() {  
        return orderDetailSortService.findAllOrderDetailByAmountDesc();
    }
    

}
