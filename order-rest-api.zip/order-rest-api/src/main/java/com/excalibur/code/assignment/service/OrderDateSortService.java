package com.excalibur.code.assignment.service;

import java.util.List;

import com.excalibur.code.assignment.model.OrderDate;

public interface OrderDateSortService {

    List<OrderDate> findAllOrderByDateAsc();
   
}