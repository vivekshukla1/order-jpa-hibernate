package com.excalibur.code.assignment.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.excalibur.code.assignment.model.OrderCombined;
import com.excalibur.code.assignment.model.OrderDetail;


@Repository
public interface OrderCombinedRepository extends JpaRepository<OrderCombined, Long>{
	
	@Query("FROM OrderCombined ORDER BY order_id ASC")
    List<OrderCombined> findAllOrderCombinedDetailByOrderId();
	
	@Modifying
	@Query("DELETE FROM OrderCombined")
    void deleteAll();
	
	//@Query("SELECT u FROM OrderCombined u WHERE LOWER(?1) = LOWER(?2)")
	 @Query("SELECT u FROM OrderCombined u WHERE u.order_description = ?1")
     //Page<OrderCombined> findByFilter(Pageable pageable, String value, String filter);
	 Page<OrderCombined> findByFilter(Pageable pageable, String value);
	 //List<OrderCombined> findByFilter(String value, String filter);
//	 List<OrderCombined> findByFilter(String value);
}
